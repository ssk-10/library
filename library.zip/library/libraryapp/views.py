from django.shortcuts import render, redirect
from .models import *
# Create your views here.
def index(request):
    return render(request,'index.html')

def signup(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phone_number = request.POST.get('phone_number')

        # Check if user with provided email already exists
        if User.objects.filter(email=email).exists():
            return render(request, 'signup.html', {'error_message': 'User already exists; Please Consider To Login.'})

        # Create new user
        user = User(name=name, email=email, phone= phone_number ,password=password)
        user.save()
        return redirect('/login/?status=1')
    return render(request, 'signup.html')

def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = User.objects.filter(email=email).first()

        if user is not None:
            if user.password == password:
                request.session['id'] = user.id
                request.session['username'] = user.name
                request.session['email'] = user.email
                return redirect('/?status=1') 
            return render(request, 'login.html', {'password_error': True,'error':'Wrong Password!!!'})
            
        else:
            return render(request, 'login.html', {'email_error':True,'error': 'Invalid Email ID!!!'})

    return render(request, 'login.html')


def logout(request):
    request.session['id']=None
    request.session['email']=None
    request.session['username']=None
    return redirect('/')